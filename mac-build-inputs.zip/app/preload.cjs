"use strict";

// desktop/preload.ts
var import_electron = require("electron");
async function invoke(channel, ...args) {
  const reply = await import_electron.ipcRenderer.invoke(channel, ...args);
  if (!reply.ok) {
    const error = new Error(reply.error.message);
    Object.assign(error, { code: reply.error.code });
    throw error;
  }
  return reply.value;
}
import_electron.contextBridge.exposeInMainWorld("desktopGrowth", {
  readState: () => invoke("growth:read"),
  saveState: (state, options) => invoke("growth:save", state, options),
  exportBackup: () => invoke("growth:export"),
  importBackup: () => invoke("growth:import"),
  importImages: () => invoke("growth:images"),
  imageUrl: (id) => {
    if (typeof id !== "string" || !/^[a-f0-9]{64}$/.test(id)) throw new Error("\u56FE\u7247\u7F16\u53F7\u4E0D\u6B63\u786E\u3002");
    return `work-image://assets/${id}`;
  },
  getInfo: () => invoke("growth:info"),
  openDataFolder: () => invoke("growth:folder"),
  openExternal: (url) => invoke("growth:external", url)
});
