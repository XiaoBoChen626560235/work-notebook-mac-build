// Run only on a disposable Intel macOS CI runner after packaging the real .app.
// This script starts that bundle; it never substitutes a development Electron.
import assert from 'node:assert/strict';
import { spawn, execFile } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createReadStream, createWriteStream } from 'node:fs';
import { lstat, mkdir, readFile, stat, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { finished } from 'node:stream/promises';
import { promisify } from 'node:util';

const execute = promisify(execFile);
const sleep = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));
const releaseDirectory = path.resolve('release');
const reportPath = path.join(releaseDirectory, 'mac-launch-check.json');
const report = {
  ok: false,
  checkedAt: new Date().toISOString(),
  runtime: { platform: process.platform, arch: process.arch, ci: process.env.CI === 'true' },
  actualPackagedAppLaunched: false,
  rendererInitialReadDetected: false,
  blankStateVerified: false,
  manualFeaturesVerified: false,
  limitation: 'This checks bundle/signature integrity and a real launch through the renderer initial-state IPC. It does not inspect the DOM or prove every manual editing, image, backup, keyboard, or window feature.',
};
let child;
let exitResult;
let childExited;
let stdoutLog;
let stderrLog;
let failure;

async function command(executable, arguments_) {
  return execute(executable, arguments_, { encoding: 'utf8', timeout: 10_000, maxBuffer: 1_000_000 });
}

async function requireAbsent(filename) {
  try { await lstat(filename); }
  catch (error) { if (error.code === 'ENOENT') return; throw error; }
  throw new Error(`Refusing to start: an existing user data directory is present: ${filename}`);
}

function requireRunning() {
  assert.equal(exitResult, undefined, `The packaged app exited before startup verification: ${JSON.stringify(exitResult)}`);
  assert.equal(child.exitCode, null, 'The packaged app exited before startup verification.');
  assert.equal(child.signalCode, null, 'The packaged app was terminated before startup verification.');
}

async function terminateOwnChild() {
  if (!child || exitResult !== undefined) return;
  // Only signal the child this script created. No process-name or PID-wide cleanup.
  child.kill('SIGTERM');
  const waitForExit = milliseconds => new Promise(resolve => {
    const timeout = setTimeout(() => resolve(null), milliseconds);
    childExited.then(result => { clearTimeout(timeout); resolve(result); });
  });
  let result = await waitForExit(5_000);
  if (!result) {
    child.kill('SIGKILL');
    result = await waitForExit(2_000);
  }
  assert.ok(result, 'The verification child did not exit after termination.');
  report.stoppedByVerifier = true;
  report.processExit = result;
}

async function checksum(filename) {
  const hash = createHash('sha256');
  let bytes = 0;
  for await (const chunk of createReadStream(filename)) { hash.update(chunk); bytes += chunk.length; }
  return { path: filename, bytes, sha256: hash.digest('hex') };
}

try {
  let appPath = path.resolve('release/mac/工作手记.app');
  let zipPath;
  const arguments_ = process.argv.slice(2);
  for (let index = 0; index < arguments_.length; index++) {
    const option = arguments_[index];
    assert.ok(['--app', '--zip'].includes(option), `Unknown option: ${option}`);
    const value = arguments_[++index];
    assert.ok(value && !value.startsWith('--'), `Missing value for ${option}`);
    if (option === '--app') appPath = path.resolve(value); else zipPath = path.resolve(value);
  }

  assert.equal(process.platform, 'darwin', 'This check requires actual macOS.');
  assert.equal(process.arch, 'x64', 'This check requires an x64 macOS Node runtime.');
  assert.equal(process.env.CI, 'true', 'This check is only allowed on a disposable CI runner.');
  assert.ok((await stat(appPath)).isDirectory(), 'The supplied .app bundle is missing.');
  const dataDirectory = path.join(os.homedir(), 'Library', 'Application Support', 'GrowthJournalDesktop');
  await requireAbsent(dataDirectory);
  report.appPath = appPath;
  report.dataDirectory = dataDirectory;
  report.userDataWasAbsent = true;

  const plist = path.join(appPath, 'Contents', 'Info.plist');
  const plistValue = async key => (await command('/usr/libexec/PlistBuddy', ['-c', `Print :${key}`, plist])).stdout.trim();
  const executableName = await plistValue('CFBundleExecutable');
  assert.ok(executableName && executableName !== '.' && executableName !== '..' && !/[\\/\0]/.test(executableName), 'The bundle executable name is invalid.');
  const version = await plistValue('CFBundleVersion');
  const minimumSystemVersion = await plistValue('LSMinimumSystemVersion');
  assert.ok(version && minimumSystemVersion, 'The bundle version or minimum macOS version is missing.');
  report.bundle = { executableName, version, minimumSystemVersion };

  const executablePath = path.join(appPath, 'Contents', 'MacOS', executableName);
  assert.ok((await stat(executablePath)).isFile(), 'The bundled executable is missing.');
  const architecture = (await command('/usr/bin/file', ['-b', executablePath])).stdout.trim();
  assert.match(architecture, /Mach-O 64-bit executable x86_64/, 'The real app executable must be Mach-O x86_64.');
  assert.doesNotMatch(architecture, /arm64/, 'This delivery targets Intel x64 only.');
  report.executableArchitecture = architecture;

  const signature = await command('/usr/bin/codesign', ['--verify', '--deep', '--strict', appPath]);
  const signatureDetails = await command('/usr/bin/codesign', ['--display', '--verbose=4', executablePath]);
  const details = `${signatureDetails.stdout}${signatureDetails.stderr}`;
  report.signature = {
    verifiedDeepStrict: true,
    adHoc: /^Signature=adhoc\s*$/m.test(details),
    verificationOutput: `${signature.stdout}${signature.stderr}`.trim(),
    executableDetails: details.trim(),
  };
  if (zipPath) {
    assert.equal(path.extname(zipPath).toLowerCase(), '.zip', '--zip must refer to the delivered ZIP archive.');
    assert.ok((await stat(zipPath)).isFile(), 'The delivered ZIP archive is missing.');
    report.artifact = await checksum(zipPath);
  }

  // Recheck immediately before spawning: this test must never open existing notes.
  await requireAbsent(dataDirectory);
  await mkdir(releaseDirectory, { recursive: true });
  const stdoutPath = path.join(releaseDirectory, 'mac-launch-stdout.log');
  const stderrPath = path.join(releaseDirectory, 'mac-launch-stderr.log');
  stdoutLog = createWriteStream(stdoutPath, { mode: 0o600 });
  stderrLog = createWriteStream(stderrPath, { mode: 0o600 });
  for (const stream of [stdoutLog, stderrLog]) stream.on('error', error => { failure ??= error; report.logError = error.message; });
  report.logs = { stdout: stdoutPath, stderr: stderrPath };
  const environment = { ...process.env };
  delete environment.ELECTRON_RUN_AS_NODE;
  delete environment.GROWTH_DESKTOP_DEV_URL;
  child = spawn(executablePath, [], { cwd: path.dirname(appPath), env: environment, stdio: ['ignore', 'pipe', 'pipe'] });
  child.once('spawn', () => { report.actualPackagedAppLaunched = true; });
  child.stdout.pipe(stdoutLog, { end: false });
  child.stderr.pipe(stderrLog, { end: false });
  childExited = new Promise(resolve => {
    child.once('exit', (code, signal) => { exitResult = { code, signal }; resolve(exitResult); });
    child.once('error', error => { exitResult = { error: error.message }; resolve(exitResult); });
  });
  const beganAt = Date.now();
  const deadline = beganAt + 12_000;
  const statePath = path.join(dataDirectory, 'growth-state.json');
  let state;
  while (Date.now() < deadline) {
    requireRunning();
    try {
      const information = await stat(statePath);
      assert.ok(information.isFile() && information.size <= 1_000_000, 'The initial state file is invalid.');
      state = JSON.parse(await readFile(statePath, 'utf8'));
      break;
    } catch (error) { if (error.code !== 'ENOENT') throw error; }
    await sleep(100);
  }
  assert.ok(state, 'The packaged renderer did not initialize its state within 12 seconds.');
  assert.equal(state.schemaVersion, 1);
  assert.equal(state.revision, 0);
  assert.deepEqual(state.categories, [{ id: 'work', name: '未分类', parentId: null }]);
  assert.deepEqual(state.records, []);
  assert.deepEqual(state.skills, []);
  assert.deepEqual(state.weeklyReviews, []);
  requireRunning();
  // Only the renderer's startup growth:read handler creates this default file.
  report.actualPackagedAppLaunched = true;
  report.rendererInitialReadDetected = true;
  report.blankStateVerified = true;
  report.initialState = { path: statePath, schemaVersion: state.schemaVersion, revision: state.revision, categories: state.categories, records: 0, skills: 0, weeklyReviews: 0 };
  report.initialStateObservedAfterMs = Date.now() - beganAt;
  await sleep(750);
  requireRunning();
} catch (error) {
  failure = error;
  report.error = error.stack || error.message || String(error);
} finally {
  try { await terminateOwnChild(); }
  catch (error) { failure ??= error; report.terminationError = error.stack || String(error); }
  for (const stream of [stdoutLog, stderrLog]) {
    if (!stream) continue;
    try { stream.end(); await finished(stream); }
    catch (error) { failure ??= error; report.logError = error.message || String(error); }
  }
  if (exitResult) report.processExit = exitResult;
  report.ok = !failure;
  await mkdir(releaseDirectory, { recursive: true });
  await writeFile(reportPath, `${JSON.stringify(report, null, 2)}\n`, { mode: 0o600 });
  console.log(JSON.stringify(report, null, 2));
  if (failure) process.exitCode = 1;
}
