import { spawn } from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const archiveArgument = process.argv.indexOf('--archive');
if (archiveArgument !== -1 && (!process.argv[archiveArgument + 1] || process.argv[archiveArgument + 1].startsWith('--'))) throw new Error('Missing value for --archive.');
const archive = archiveArgument === -1 ? path.join(root, 'release', 'mac', '工作手记.app', 'Contents', 'Resources', 'app.asar') : path.resolve(root, process.argv[archiveArgument + 1]);
const reportFile = path.join(root, 'release', 'mac-native-smoke.json');
const require = createRequire(import.meta.url);
if (process.platform !== 'darwin' || process.arch !== 'x64') throw new Error('Run this smoke test on an Intel (x64) Mac build runner.');
await fs.access(archive);
await fs.mkdir(path.dirname(reportFile), { recursive: true });
await fs.rm(reportFile, { force: true });
const env = { ...process.env };
delete env.ELECTRON_RUN_AS_NODE;
const child = spawn(require('electron'), [path.join(root, 'tests', 'desktop-runtime-smoke.cjs'), '--archive', archive, '--fixture', path.join(root, 'tests', 'fixtures', 'inline-flow.png'), '--backup-codec', path.join(root, 'tests', 'backup-smoke-codec.mjs'), '--report', reportFile], { cwd: root, env, stdio: 'inherit', windowsHide: true });
const tempRoot = path.join(root, '.sites-runtime', 'desktop-smoke-' + child.pid);
function requireInside(parent, target) {
  const relative = path.relative(parent, target);
  if (!relative || relative === '..' || relative.startsWith('..' + path.sep) || path.isAbsolute(relative)) throw new Error('Unsafe smoke cleanup path: ' + target);
}
async function rejectLinks(parent, directory) {
  for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
    const target = path.join(directory, entry.name);
    const info = await fs.lstat(target);
    if (info.isSymbolicLink()) throw new Error('Symbolic link in smoke temporary directory.');
    requireInside(parent, await fs.realpath(target));
    if (info.isDirectory()) await rejectLinks(parent, target);
  }
}
let timeout, termination;
try {
  const code = await new Promise((resolve, reject) => {
    child.once('error', reject);
    child.once('exit', (exitCode, signal) => { clearTimeout(timeout); clearTimeout(termination); signal ? reject(new Error('Electron smoke exited with ' + signal)) : resolve(exitCode); });
    timeout = setTimeout(() => { child.kill('SIGTERM'); termination = setTimeout(() => child.kill('SIGKILL'), 5000); }, 70000);
  });
  const report = JSON.parse(await fs.readFile(reportFile, 'utf8'));
  if (code !== 0 || report.status !== 'PASS' || report.loadedFromArchive !== true || report.platform !== 'darwin' || report.architecture !== 'x64' || report.macMenuChecked !== true) throw new Error('Mac archive smoke failed; inspect release/mac-native-smoke.json.');
  if (path.resolve(report.tempRoot) !== tempRoot) throw new Error('Native test reported an unexpected temporary directory.');
  console.log('Mac archive smoke: PASS');
} finally {
  clearTimeout(timeout); clearTimeout(termination);
  if (Number.isInteger(child.pid)) {
    requireInside(path.join(root, '.sites-runtime'), tempRoot);
    try {
      const parentInfo = await fs.lstat(path.join(root, '.sites-runtime'));
      const info = await fs.lstat(tempRoot);
      if (parentInfo.isSymbolicLink() || info.isSymbolicLink() || !info.isDirectory()) throw new Error('Unsafe smoke temporary directory.');
      requireInside(await fs.realpath(root), await fs.realpath(tempRoot));
      await rejectLinks(await fs.realpath(tempRoot), tempRoot);
      await fs.rm(tempRoot, { recursive: true, force: false });
    } catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
}
