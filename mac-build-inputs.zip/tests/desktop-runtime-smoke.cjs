// Run with the installed Electron binary. This uses the actual compiled main,
// preload and renderer, while redirecting appData to a throwaway test folder.
const { app, BrowserWindow, dialog } = require('electron');
const fs = require('node:fs/promises');
const syncFs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
function argument(name, fallback) {
  const index = process.argv.indexOf(name);
  if (index < 0) return fallback;
  const value = process.argv[index + 1];
  if (!value || value.startsWith('--')) throw new Error(`Missing value for ${name}`);
  return value;
}
const runtimeDirectory = path.resolve(argument('--archive', process.argv.includes('--packaged-archive') ? 'outputs/desktop/win-unpacked/resources/app.asar' : '.desktop-build'));
const fixturePath = path.resolve(argument('--fixture', 'tests/fixtures/inline-flow.png'));
const codecPath = path.resolve(argument('--backup-codec', '.sites-runtime/backup-smoke-codec.mjs'));
const reportPath = path.resolve(argument('--report', 'outputs/desktop/native-smoke.json'));
const startedAt = Date.now();
const stages = [];
let stage = 'initializing-harness';
let completed = false;
let timeout;
function checkpoint(name) {
  stage = name;
  const entry = { stage, elapsedMs: Date.now() - startedAt };
  stages.push(entry);
  console.log(`[desktop-smoke] ${stage} (${entry.elapsedMs} ms)`);
}
function fail(error) {
  if (completed) return;
  completed = true; clearTimeout(timeout);
  console.error(`[desktop-smoke] FAIL at ${stage}`, error);
  // Persist synchronously before app.exit; timeout and load failures must not
  // leave a missing report that obscures the original failed stage.
  try {
    syncFs.mkdirSync(path.dirname(reportPath), { recursive: true });
    syncFs.writeFileSync(reportPath, JSON.stringify({ status: 'FAIL', platform: process.platform, architecture: process.arch, stage, stages, error: error.stack || String(error), tempRoot }, null, 2));
  } catch (reportError) { console.error('Unable to write the failure report:', reportError); }
  app.exit(1);
}
const packageInfo = require(path.join(runtimeDirectory, 'package.json'));
app.getVersion = () => packageInfo.version;

const tempRoot = path.resolve('.sites-runtime', `desktop-smoke-${process.pid}`);
syncFs.mkdirSync(path.join(tempRoot, 'GrowthJournalDesktop'), { recursive: true });
const getPath = app.getPath.bind(app);
app.getPath = name => name === 'appData' ? tempRoot : getPath(name);
app.setPath('userData', path.join(tempRoot, 'GrowthJournalDesktop'));
const exportPath = path.join(tempRoot, 'native-progress-backup.json');
const imageBackupPath = path.join(tempRoot, 'native-picture-backup.zip');
// This test owns the hidden window and destination; no user dialog is shown.
dialog.showSaveDialog = async (_window, options) => ({ canceled: false, filePath: options.defaultPath.endsWith('.zip') ? imageBackupPath : exportPath });
dialog.showOpenDialog = async (_window, options) => {
  if (options.title === '插入本地图片') return { canceled: false, filePaths: [fixturePath] };
  // Simulate moving a ZIP onto a computer without this asset. Only this test's
  // temporary image file is removed, and import must recreate it from the ZIP.
  const current = JSON.parse(await fs.readFile(path.join(tempRoot, 'GrowthJournalDesktop', 'growth-state.json'), 'utf8'));
  await fs.unlink(path.join(tempRoot, 'GrowthJournalDesktop', 'assets', current.records[0].images[0].id));
  return { canceled: false, filePaths: [imageBackupPath] };
};
app.commandLine.appendSwitch('disable-gpu');
timeout = setTimeout(() => fail(new Error('Desktop runtime smoke timed out')), 25_000);
process.on('uncaughtException', fail);
process.on('unhandledRejection', fail);
app.on('ready', () => checkpoint('app-ready'));
app.on('second-instance', () => console.log(`[desktop-smoke] second-instance during ${stage}`));
app.on('activate', () => console.log(`[desktop-smoke] activate during ${stage}`));
app.on('will-quit', () => { if (!completed) fail(new Error('The app quit before smoke verification completed.')); });
app.on('browser-window-created', (_event, window) => {
  checkpoint('window-created');
  // This test intentionally hides its own window. Keep renderer timers and
  // painting active on macOS while leaving the production configuration alone.
  window.webContents.setBackgroundThrottling(false);
  window.setSkipTaskbar(true);
  window.on('show', () => window.hide());
  window.webContents.once('did-finish-load', async () => {
    try {
      checkpoint('renderer-loaded-initial-bridge');
      const result = await window.webContents.executeJavaScript(`(async () => {
        const state = await window.desktopGrowth.readState();
        const info = await window.desktopGrowth.getInfo();
        let unsafeBlocked = false;
        try { await window.desktopGrowth.openExternal('file:///C:/Windows'); }
        catch (error) { unsafeBlocked = /仅支持 http 或 https/.test(error.message); }
        return { bridge: Object.keys(window.desktopGrowth).sort(), categories: state.categories.map(c => c.id), recordCount: state.records.length,
          revision: state.revision, info, unsafeBlocked, nodeIntegration: typeof require, title: document.title,
          text: document.body.innerText, width: document.documentElement.clientWidth, scrollWidth: document.documentElement.scrollWidth };
      })()`);
      assert.deepEqual(result.categories, ['work']);
      assert.equal(result.recordCount, 0);
      assert.equal(result.revision, 0);
      assert.equal(result.nodeIntegration, 'undefined');
      assert.equal(result.unsafeBlocked, true);
      assert.ok(result.info.dataPath.startsWith(tempRoot));
      assert.equal(result.info.platform, process.platform);
      assert.match(result.title, /工作手记/);
      checkpoint('initial-renderer-paint');
      // The renderer's state is set after its own read promise; let React paint.
      const paint = await window.webContents.executeJavaScript(`new Promise(resolve => setTimeout(() => resolve(document.body.innerText), 200))`);
      assert.match(paint, /灵感/);
      assert.match(paint, /流程/);
      assert.match(paint, /进度/);
      assert.doesNotMatch(paint, /重新登录|云端同步/);
      assert.equal(await window.webContents.executeJavaScript(`document.querySelectorAll('input[type="password"],input[type="email"]').length`), 0);
      assert.equal(result.scrollWidth, result.width);
      checkpoint('progress-save-read-json-export');
      const roundtrip = await window.webContents.executeJavaScript(`(async () => {
        const before = await window.desktopGrowth.readState();
        const timestamp = new Date().toISOString();
        const progress = { id: 'native_progress', kind: 'progress', date: '2026-10-10', categoryId: 'work', title: '原生进度验证', done: '完成第一阶段', learned: '保留经验', next: '继续下一步', tags: ['验证'], links: [], createdAt: timestamp, updatedAt: timestamp };
        const saved = await window.desktopGrowth.saveState({ ...before, records: [progress] });
        const reread = await window.desktopGrowth.readState();
        const exported = await window.desktopGrowth.exportBackup();
        return { initialSchema: before.schemaVersion, saved, reread, exported };
      })()`);
      assert.equal(roundtrip.initialSchema, 1);
      assert.equal(roundtrip.saved.schemaVersion, 2);
      assert.equal(roundtrip.saved.records[0].kind, 'progress');
      assert.equal(roundtrip.saved.revision, 1);
      assert.deepEqual(roundtrip.reread, roundtrip.saved);
      assert.equal(roundtrip.exported.cancelled, false);
      assert.equal(roundtrip.exported.path, exportPath);
      assert.deepEqual(JSON.parse(await fs.readFile(exportPath, 'utf8')), roundtrip.saved);
      checkpoint('image-protocol-save-zip-restore');
      const imageRoundtrip = await window.webContents.executeJavaScript(`(async () => {
        const imported = await window.desktopGrowth.importImages();
        if (imported.cancelled || imported.images.length !== 1) throw new Error('native image picker failed');
        const image = imported.images[0];
        let invalidIdBlocked = false;
        try { window.desktopGrowth.imageUrl('../growth-state.json'); } catch { invalidIdBlocked = true; }
        const loaded = await new Promise((resolve, reject) => {
          const element = document.createElement('img');
          element.onload = () => { const dimensions = { width: element.naturalWidth, height: element.naturalHeight }; element.remove(); resolve(dimensions); };
          element.onerror = () => { element.remove(); reject(new Error('native image protocol failed')); };
          element.src = window.desktopGrowth.imageUrl(image.id); document.body.appendChild(element);
        });
        const before = await window.desktopGrowth.readState();
        const blocks = [{ id: 'before_image', type: 'text', text: '完成' }, { id: 'inline_image', type: 'image', imageId: image.id }, { id: 'after_image', type: 'text', text: '第一阶段' }];
        const progress = { ...before.records[0], images: [image], blocks };
        const flow = { id: 'native_flow', categoryId: 'work', title: '图文流程验证', scenario: '保留场景', prerequisites: '', steps: '完成第一阶段', parameters: '', pitfalls: '', status: 'draft', links: [], sourceRecordIds: [progress.id], versions: [], images: [image], blocks, createdAt: progress.createdAt, updatedAt: progress.updatedAt };
        const first = await window.desktopGrowth.saveState({ ...before, records: [progress], skills: [flow] });
        const { images: _images, blocks: _blocks, ...plainFlow } = first.skills[0];
        const version = { savedAt: first.skills[0].updatedAt, title: first.skills[0].title, scenario: first.skills[0].scenario, prerequisites: '', steps: first.skills[0].steps, parameters: '', pitfalls: '', status: 'draft', links: [], images: [image], blocks };
        const saved = await window.desktopGrowth.saveState({ ...first, skills: [{ ...plainFlow, steps: '下一版文字', versions: [version] }] });
        const exported = await window.desktopGrowth.exportBackup();
        const preview = await window.desktopGrowth.importBackup();
        const afterPreview = await window.desktopGrowth.readState();
        const restored = await window.desktopGrowth.saveState({ ...preview.state, revision: afterPreview.revision }, { restore: true });
        return { image, loaded, invalidIdBlocked, saved, exported, preview, afterPreview, restored };
      })()`);
      assert.equal(imageRoundtrip.invalidIdBlocked, true);
      assert.deepEqual(imageRoundtrip.loaded, { width: 900, height: 320 });
      assert.equal(imageRoundtrip.saved.schemaVersion, 3);
      assert.deepEqual(imageRoundtrip.preview.state, imageRoundtrip.saved);
      assert.deepEqual(imageRoundtrip.afterPreview, imageRoundtrip.saved);
      assert.deepEqual(imageRoundtrip.restored.records, imageRoundtrip.saved.records);
      assert.deepEqual(imageRoundtrip.restored.skills, imageRoundtrip.saved.skills);
      assert.equal(imageRoundtrip.exported.path, imageBackupPath);
      checkpoint('verify-exported-zip-bytes');
      const archive = await fs.readFile(imageBackupPath);
      assert.equal(archive.subarray(0, 2).toString(), 'PK');
      const { decodeImageBackup } = await import(require('node:url').pathToFileURL(codecPath).href);
      const decoded = decodeImageBackup(archive);
      assert.deepEqual(decoded.state, imageRoundtrip.saved);
      assert.equal(decoded.assets.size, 1);
      assert.deepEqual(decoded.assets.get(imageRoundtrip.image.id), await fs.readFile(fixturePath));
      checkpoint('renderer-reload');
      await new Promise(resolve => { window.webContents.once('did-finish-load', resolve); window.webContents.reload(); });
      checkpoint('verify-reopened-inline-editor');
      const uiImage = await window.webContents.executeJavaScript(`new Promise(resolve => setTimeout(() => {
        const button = [...document.querySelectorAll('.note-open')].find(element => element.innerText.includes('原生进度验证')); button?.click();
        setTimeout(() => resolve({ inlineImages: [...document.querySelectorAll('.editor-drawer img')].map(image => ({ width: image.naturalWidth, height: image.naturalHeight })), paragraphs: [...document.querySelectorAll('.editor-drawer textarea')].map(text => text.value) }), 200);
      }, 200))`);
      assert.deepEqual(uiImage.inlineImages, [{ width: 900, height: 320 }]);
      assert.deepEqual(uiImage.paragraphs, ['完成', '第一阶段']);
      checkpoint('verify-platform-shortcut-and-menu');
      const editorText = await window.webContents.executeJavaScript('document.body.innerText');
      assert.ok(editorText.includes(process.platform === 'darwin' ? '⌘+S' : 'Ctrl+S'));
      if (process.platform === 'darwin') {
        const { Menu } = require('electron');
        const menu = Menu.getApplicationMenu();
        assert.ok(menu.items.some(item => item.label === '编辑' && item.submenu.items.some(child => child.role === 'copy')));
        assert.ok(menu.items.some(item => item.label === '工作手记' && item.submenu.items.some(child => child.role === 'quit')));
      }
      await fs.mkdir(path.dirname(reportPath), { recursive: true });
      const report = { status: 'PASS', platform: process.platform, architecture: process.arch, runtime: process.versions.electron, productVersion: packageInfo.version, loadedFromArchive: runtimeDirectory.endsWith('app.asar'), bridge: result.bridge, categories: result.categories, title: result.title, nodeIntegration: result.nodeIntegration, unsafeExternalBlocked: result.unsafeBlocked, dataRedirected: true, rendererLoaded: true, tempRoot,
        progressSavedReadAndExported: true, progressSchemaVersion: roundtrip.saved.schemaVersion,
        imagePickerImported: true, imageProtocolDecoded: true, mixedBlocksRendered: true, imageBackupRestored: true, restoredMissingAsset: true, historyImagesIncluded: true, imageSchemaVersion: 3,
        platformShortcutShown: true, macMenuChecked: process.platform === 'darwin', stages, elapsedMs: Date.now() - startedAt };
      await fs.writeFile(reportPath, JSON.stringify(report, null, 2));
      console.log(JSON.stringify(report, null, 2));
      completed = true; clearTimeout(timeout); app.exit(0);
    } catch (error) {
      fail(error);
    }
  });
  window.webContents.once('did-fail-load', (_e, code, message) => fail(new Error(`Renderer failed: ${code} ${message}`)));
  window.webContents.on('render-process-gone', (_event, details) => fail(new Error(`Renderer process exited: ${JSON.stringify(details)}`)));
});
checkpoint('loading-actual-main');
try { require(path.join(runtimeDirectory, 'main.cjs')); }
catch (error) { fail(error); }
