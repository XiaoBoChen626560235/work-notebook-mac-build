// desktop/backup-zip.ts
import { createHash } from "node:crypto";

// node_modules/fflate/esm/index.mjs
import { createRequire } from "module";
var require2 = createRequire("/");
var Worker;
try {
  Worker = require2("worker_threads").Worker;
} catch (e) {
}
var u8 = Uint8Array;
var u16 = Uint16Array;
var u32 = Uint32Array;
var fleb = new u8([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  0,
  /* unused */
  0,
  0,
  /* impossible */
  0
]);
var fdeb = new u8([
  0,
  0,
  0,
  0,
  1,
  1,
  2,
  2,
  3,
  3,
  4,
  4,
  5,
  5,
  6,
  6,
  7,
  7,
  8,
  8,
  9,
  9,
  10,
  10,
  11,
  11,
  12,
  12,
  13,
  13,
  /* unused */
  0,
  0
]);
var clim = new u8([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
var freb = function(eb, start) {
  var b = new u16(31);
  for (var i2 = 0; i2 < 31; ++i2) {
    b[i2] = start += 1 << eb[i2 - 1];
  }
  var r = new u32(b[30]);
  for (var i2 = 1; i2 < 30; ++i2) {
    for (var j = b[i2]; j < b[i2 + 1]; ++j) {
      r[j] = j - b[i2] << 5 | i2;
    }
  }
  return [b, r];
};
var _a = freb(fleb, 2);
var fl = _a[0];
var revfl = _a[1];
fl[28] = 258, revfl[258] = 28;
var _b = freb(fdeb, 0);
var fd = _b[0];
var revfd = _b[1];
var rev = new u16(32768);
for (i = 0; i < 32768; ++i) {
  x = (i & 43690) >>> 1 | (i & 21845) << 1;
  x = (x & 52428) >>> 2 | (x & 13107) << 2;
  x = (x & 61680) >>> 4 | (x & 3855) << 4;
  rev[i] = ((x & 65280) >>> 8 | (x & 255) << 8) >>> 1;
}
var x;
var i;
var hMap = (function(cd, mb, r) {
  var s = cd.length;
  var i2 = 0;
  var l = new u16(mb);
  for (; i2 < s; ++i2) {
    if (cd[i2])
      ++l[cd[i2] - 1];
  }
  var le = new u16(mb);
  for (i2 = 0; i2 < mb; ++i2) {
    le[i2] = le[i2 - 1] + l[i2 - 1] << 1;
  }
  var co;
  if (r) {
    co = new u16(1 << mb);
    var rvb = 15 - mb;
    for (i2 = 0; i2 < s; ++i2) {
      if (cd[i2]) {
        var sv = i2 << 4 | cd[i2];
        var r_1 = mb - cd[i2];
        var v = le[cd[i2] - 1]++ << r_1;
        for (var m = v | (1 << r_1) - 1; v <= m; ++v) {
          co[rev[v] >>> rvb] = sv;
        }
      }
    }
  } else {
    co = new u16(s);
    for (i2 = 0; i2 < s; ++i2) {
      if (cd[i2]) {
        co[i2] = rev[le[cd[i2] - 1]++] >>> 15 - cd[i2];
      }
    }
  }
  return co;
});
var flt = new u8(288);
for (i = 0; i < 144; ++i)
  flt[i] = 8;
var i;
for (i = 144; i < 256; ++i)
  flt[i] = 9;
var i;
for (i = 256; i < 280; ++i)
  flt[i] = 7;
var i;
for (i = 280; i < 288; ++i)
  flt[i] = 8;
var i;
var fdt = new u8(32);
for (i = 0; i < 32; ++i)
  fdt[i] = 5;
var i;
var flm = /* @__PURE__ */ hMap(flt, 9, 0);
var fdm = /* @__PURE__ */ hMap(fdt, 5, 0);
var shft = function(p) {
  return (p + 7) / 8 | 0;
};
var slc = function(v, s, e) {
  if (s == null || s < 0)
    s = 0;
  if (e == null || e > v.length)
    e = v.length;
  var n = new (v.BYTES_PER_ELEMENT == 2 ? u16 : v.BYTES_PER_ELEMENT == 4 ? u32 : u8)(e - s);
  n.set(v.subarray(s, e));
  return n;
};
var ec = [
  "unexpected EOF",
  "invalid block type",
  "invalid length/literal",
  "invalid distance",
  "stream finished",
  "no stream handler",
  ,
  "no callback",
  "invalid UTF-8 data",
  "extra field too long",
  "date not in range 1980-2099",
  "filename too long",
  "stream finishing",
  "invalid zip data"
  // determined by unknown compression method
];
var err = function(ind, msg, nt) {
  var e = new Error(msg || ec[ind]);
  e.code = ind;
  if (Error.captureStackTrace)
    Error.captureStackTrace(e, err);
  if (!nt)
    throw e;
  return e;
};
var wbits = function(d, p, v) {
  v <<= p & 7;
  var o = p / 8 | 0;
  d[o] |= v;
  d[o + 1] |= v >>> 8;
};
var wbits16 = function(d, p, v) {
  v <<= p & 7;
  var o = p / 8 | 0;
  d[o] |= v;
  d[o + 1] |= v >>> 8;
  d[o + 2] |= v >>> 16;
};
var hTree = function(d, mb) {
  var t = [];
  for (var i2 = 0; i2 < d.length; ++i2) {
    if (d[i2])
      t.push({ s: i2, f: d[i2] });
  }
  var s = t.length;
  var t2 = t.slice();
  if (!s)
    return [et, 0];
  if (s == 1) {
    var v = new u8(t[0].s + 1);
    v[t[0].s] = 1;
    return [v, 1];
  }
  t.sort(function(a, b) {
    return a.f - b.f;
  });
  t.push({ s: -1, f: 25001 });
  var l = t[0], r = t[1], i0 = 0, i1 = 1, i22 = 2;
  t[0] = { s: -1, f: l.f + r.f, l, r };
  while (i1 != s - 1) {
    l = t[t[i0].f < t[i22].f ? i0++ : i22++];
    r = t[i0 != i1 && t[i0].f < t[i22].f ? i0++ : i22++];
    t[i1++] = { s: -1, f: l.f + r.f, l, r };
  }
  var maxSym = t2[0].s;
  for (var i2 = 1; i2 < s; ++i2) {
    if (t2[i2].s > maxSym)
      maxSym = t2[i2].s;
  }
  var tr = new u16(maxSym + 1);
  var mbt = ln(t[i1 - 1], tr, 0);
  if (mbt > mb) {
    var i2 = 0, dt = 0;
    var lft = mbt - mb, cst = 1 << lft;
    t2.sort(function(a, b) {
      return tr[b.s] - tr[a.s] || a.f - b.f;
    });
    for (; i2 < s; ++i2) {
      var i2_1 = t2[i2].s;
      if (tr[i2_1] > mb) {
        dt += cst - (1 << mbt - tr[i2_1]);
        tr[i2_1] = mb;
      } else
        break;
    }
    dt >>>= lft;
    while (dt > 0) {
      var i2_2 = t2[i2].s;
      if (tr[i2_2] < mb)
        dt -= 1 << mb - tr[i2_2]++ - 1;
      else
        ++i2;
    }
    for (; i2 >= 0 && dt; --i2) {
      var i2_3 = t2[i2].s;
      if (tr[i2_3] == mb) {
        --tr[i2_3];
        ++dt;
      }
    }
    mbt = mb;
  }
  return [new u8(tr), mbt];
};
var ln = function(n, l, d) {
  return n.s == -1 ? Math.max(ln(n.l, l, d + 1), ln(n.r, l, d + 1)) : l[n.s] = d;
};
var lc = function(c) {
  var s = c.length;
  while (s && !c[--s])
    ;
  var cl = new u16(++s);
  var cli = 0, cln = c[0], cls = 1;
  var w = function(v) {
    cl[cli++] = v;
  };
  for (var i2 = 1; i2 <= s; ++i2) {
    if (c[i2] == cln && i2 != s)
      ++cls;
    else {
      if (!cln && cls > 2) {
        for (; cls > 138; cls -= 138)
          w(32754);
        if (cls > 2) {
          w(cls > 10 ? cls - 11 << 5 | 28690 : cls - 3 << 5 | 12305);
          cls = 0;
        }
      } else if (cls > 3) {
        w(cln), --cls;
        for (; cls > 6; cls -= 6)
          w(8304);
        if (cls > 2)
          w(cls - 3 << 5 | 8208), cls = 0;
      }
      while (cls--)
        w(cln);
      cls = 1;
      cln = c[i2];
    }
  }
  return [cl.subarray(0, cli), s];
};
var clen = function(cf, cl) {
  var l = 0;
  for (var i2 = 0; i2 < cl.length; ++i2)
    l += cf[i2] * cl[i2];
  return l;
};
var wfblk = function(out, pos, dat) {
  var s = dat.length;
  var o = shft(pos + 2);
  out[o] = s & 255;
  out[o + 1] = s >>> 8;
  out[o + 2] = out[o] ^ 255;
  out[o + 3] = out[o + 1] ^ 255;
  for (var i2 = 0; i2 < s; ++i2)
    out[o + i2 + 4] = dat[i2];
  return (o + 4 + s) * 8;
};
var wblk = function(dat, out, final, syms, lf, df, eb, li, bs, bl, p) {
  wbits(out, p++, final);
  ++lf[256];
  var _a2 = hTree(lf, 15), dlt = _a2[0], mlb = _a2[1];
  var _b2 = hTree(df, 15), ddt = _b2[0], mdb = _b2[1];
  var _c = lc(dlt), lclt = _c[0], nlc = _c[1];
  var _d = lc(ddt), lcdt = _d[0], ndc = _d[1];
  var lcfreq = new u16(19);
  for (var i2 = 0; i2 < lclt.length; ++i2)
    lcfreq[lclt[i2] & 31]++;
  for (var i2 = 0; i2 < lcdt.length; ++i2)
    lcfreq[lcdt[i2] & 31]++;
  var _e = hTree(lcfreq, 7), lct = _e[0], mlcb = _e[1];
  var nlcc = 19;
  for (; nlcc > 4 && !lct[clim[nlcc - 1]]; --nlcc)
    ;
  var flen = bl + 5 << 3;
  var ftlen = clen(lf, flt) + clen(df, fdt) + eb;
  var dtlen = clen(lf, dlt) + clen(df, ddt) + eb + 14 + 3 * nlcc + clen(lcfreq, lct) + (2 * lcfreq[16] + 3 * lcfreq[17] + 7 * lcfreq[18]);
  if (flen <= ftlen && flen <= dtlen)
    return wfblk(out, p, dat.subarray(bs, bs + bl));
  var lm, ll, dm, dl;
  wbits(out, p, 1 + (dtlen < ftlen)), p += 2;
  if (dtlen < ftlen) {
    lm = hMap(dlt, mlb, 0), ll = dlt, dm = hMap(ddt, mdb, 0), dl = ddt;
    var llm = hMap(lct, mlcb, 0);
    wbits(out, p, nlc - 257);
    wbits(out, p + 5, ndc - 1);
    wbits(out, p + 10, nlcc - 4);
    p += 14;
    for (var i2 = 0; i2 < nlcc; ++i2)
      wbits(out, p + 3 * i2, lct[clim[i2]]);
    p += 3 * nlcc;
    var lcts = [lclt, lcdt];
    for (var it = 0; it < 2; ++it) {
      var clct = lcts[it];
      for (var i2 = 0; i2 < clct.length; ++i2) {
        var len = clct[i2] & 31;
        wbits(out, p, llm[len]), p += lct[len];
        if (len > 15)
          wbits(out, p, clct[i2] >>> 5 & 127), p += clct[i2] >>> 12;
      }
    }
  } else {
    lm = flm, ll = flt, dm = fdm, dl = fdt;
  }
  for (var i2 = 0; i2 < li; ++i2) {
    if (syms[i2] > 255) {
      var len = syms[i2] >>> 18 & 31;
      wbits16(out, p, lm[len + 257]), p += ll[len + 257];
      if (len > 7)
        wbits(out, p, syms[i2] >>> 23 & 31), p += fleb[len];
      var dst = syms[i2] & 31;
      wbits16(out, p, dm[dst]), p += dl[dst];
      if (dst > 3)
        wbits16(out, p, syms[i2] >>> 5 & 8191), p += fdeb[dst];
    } else {
      wbits16(out, p, lm[syms[i2]]), p += ll[syms[i2]];
    }
  }
  wbits16(out, p, lm[256]);
  return p + ll[256];
};
var deo = /* @__PURE__ */ new u32([65540, 131080, 131088, 131104, 262176, 1048704, 1048832, 2114560, 2117632]);
var et = /* @__PURE__ */ new u8(0);
var dflt = function(dat, lvl, plvl, pre, post, lst) {
  var s = dat.length;
  var o = new u8(pre + s + 5 * (1 + Math.ceil(s / 7e3)) + post);
  var w = o.subarray(pre, o.length - post);
  var pos = 0;
  if (!lvl || s < 8) {
    for (var i2 = 0; i2 <= s; i2 += 65535) {
      var e = i2 + 65535;
      if (e >= s) {
        w[pos >> 3] = lst;
      }
      pos = wfblk(w, pos + 1, dat.subarray(i2, e));
    }
  } else {
    var opt = deo[lvl - 1];
    var n = opt >>> 13, c = opt & 8191;
    var msk_1 = (1 << plvl) - 1;
    var prev = new u16(32768), head = new u16(msk_1 + 1);
    var bs1_1 = Math.ceil(plvl / 3), bs2_1 = 2 * bs1_1;
    var hsh = function(i3) {
      return (dat[i3] ^ dat[i3 + 1] << bs1_1 ^ dat[i3 + 2] << bs2_1) & msk_1;
    };
    var syms = new u32(25e3);
    var lf = new u16(288), df = new u16(32);
    var lc_1 = 0, eb = 0, i2 = 0, li = 0, wi = 0, bs = 0;
    for (; i2 < s; ++i2) {
      var hv = hsh(i2);
      var imod = i2 & 32767, pimod = head[hv];
      prev[imod] = pimod;
      head[hv] = imod;
      if (wi <= i2) {
        var rem = s - i2;
        if ((lc_1 > 7e3 || li > 24576) && rem > 423) {
          pos = wblk(dat, w, 0, syms, lf, df, eb, li, bs, i2 - bs, pos);
          li = lc_1 = eb = 0, bs = i2;
          for (var j = 0; j < 286; ++j)
            lf[j] = 0;
          for (var j = 0; j < 30; ++j)
            df[j] = 0;
        }
        var l = 2, d = 0, ch_1 = c, dif = imod - pimod & 32767;
        if (rem > 2 && hv == hsh(i2 - dif)) {
          var maxn = Math.min(n, rem) - 1;
          var maxd = Math.min(32767, i2);
          var ml = Math.min(258, rem);
          while (dif <= maxd && --ch_1 && imod != pimod) {
            if (dat[i2 + l] == dat[i2 + l - dif]) {
              var nl = 0;
              for (; nl < ml && dat[i2 + nl] == dat[i2 + nl - dif]; ++nl)
                ;
              if (nl > l) {
                l = nl, d = dif;
                if (nl > maxn)
                  break;
                var mmd = Math.min(dif, nl - 2);
                var md = 0;
                for (var j = 0; j < mmd; ++j) {
                  var ti = i2 - dif + j + 32768 & 32767;
                  var pti = prev[ti];
                  var cd = ti - pti + 32768 & 32767;
                  if (cd > md)
                    md = cd, pimod = ti;
                }
              }
            }
            imod = pimod, pimod = prev[imod];
            dif += imod - pimod + 32768 & 32767;
          }
        }
        if (d) {
          syms[li++] = 268435456 | revfl[l] << 18 | revfd[d];
          var lin = revfl[l] & 31, din = revfd[d] & 31;
          eb += fleb[lin] + fdeb[din];
          ++lf[257 + lin];
          ++df[din];
          wi = i2 + l;
          ++lc_1;
        } else {
          syms[li++] = dat[i2];
          ++lf[dat[i2]];
        }
      }
    }
    pos = wblk(dat, w, lst, syms, lf, df, eb, li, bs, i2 - bs, pos);
    if (!lst && pos & 7)
      pos = wfblk(w, pos + 1, et);
  }
  return slc(o, 0, pre + shft(pos) + post);
};
var crct = /* @__PURE__ */ (function() {
  var t = new Int32Array(256);
  for (var i2 = 0; i2 < 256; ++i2) {
    var c = i2, k = 9;
    while (--k)
      c = (c & 1 && -306674912) ^ c >>> 1;
    t[i2] = c;
  }
  return t;
})();
var crc = function() {
  var c = -1;
  return {
    p: function(d) {
      var cr = c;
      for (var i2 = 0; i2 < d.length; ++i2)
        cr = crct[cr & 255 ^ d[i2]] ^ cr >>> 8;
      c = cr;
    },
    d: function() {
      return ~c;
    }
  };
};
var dopt = function(dat, opt, pre, post, st) {
  return dflt(dat, opt.level == null ? 6 : opt.level, opt.mem == null ? Math.ceil(Math.max(8, Math.min(13, Math.log(dat.length))) * 1.5) : 12 + opt.mem, pre, post, !st);
};
var mrg = function(a, b) {
  var o = {};
  for (var k in a)
    o[k] = a[k];
  for (var k in b)
    o[k] = b[k];
  return o;
};
var wbytes = function(d, b, v) {
  for (; v; ++b)
    d[b] = v, v >>>= 8;
};
function deflateSync(data, opts) {
  return dopt(data, opts || {}, 0, 0);
}
var fltn = function(d, p, t, o) {
  for (var k in d) {
    var val = d[k], n = p + k, op = o;
    if (Array.isArray(val))
      op = mrg(o, val[1]), val = val[0];
    if (val instanceof u8)
      t[n] = [val, op];
    else {
      t[n += "/"] = [new u8(0), op];
      fltn(val, n, t, o);
    }
  }
};
var te = typeof TextEncoder != "undefined" && /* @__PURE__ */ new TextEncoder();
var td = typeof TextDecoder != "undefined" && /* @__PURE__ */ new TextDecoder();
var tds = 0;
try {
  td.decode(et, { stream: true });
  tds = 1;
} catch (e) {
}
function strToU8(str, latin1) {
  if (latin1) {
    var ar_1 = new u8(str.length);
    for (var i2 = 0; i2 < str.length; ++i2)
      ar_1[i2] = str.charCodeAt(i2);
    return ar_1;
  }
  if (te)
    return te.encode(str);
  var l = str.length;
  var ar = new u8(str.length + (str.length >> 1));
  var ai = 0;
  var w = function(v) {
    ar[ai++] = v;
  };
  for (var i2 = 0; i2 < l; ++i2) {
    if (ai + 5 > ar.length) {
      var n = new u8(ai + 8 + (l - i2 << 1));
      n.set(ar);
      ar = n;
    }
    var c = str.charCodeAt(i2);
    if (c < 128 || latin1)
      w(c);
    else if (c < 2048)
      w(192 | c >> 6), w(128 | c & 63);
    else if (c > 55295 && c < 57344)
      c = 65536 + (c & 1023 << 10) | str.charCodeAt(++i2) & 1023, w(240 | c >> 18), w(128 | c >> 12 & 63), w(128 | c >> 6 & 63), w(128 | c & 63);
    else
      w(224 | c >> 12), w(128 | c >> 6 & 63), w(128 | c & 63);
  }
  return slc(ar, 0, ai);
}
var exfl = function(ex) {
  var le = 0;
  if (ex) {
    for (var k in ex) {
      var l = ex[k].length;
      if (l > 65535)
        err(9);
      le += l + 4;
    }
  }
  return le;
};
var wzh = function(d, b, f, fn, u, c, ce, co) {
  var fl2 = fn.length, ex = f.extra, col = co && co.length;
  var exl = exfl(ex);
  wbytes(d, b, ce != null ? 33639248 : 67324752), b += 4;
  if (ce != null)
    d[b++] = 20, d[b++] = f.os;
  d[b] = 20, b += 2;
  d[b++] = f.flag << 1 | (c < 0 && 8), d[b++] = u && 8;
  d[b++] = f.compression & 255, d[b++] = f.compression >> 8;
  var dt = new Date(f.mtime == null ? Date.now() : f.mtime), y = dt.getFullYear() - 1980;
  if (y < 0 || y > 119)
    err(10);
  wbytes(d, b, y << 25 | dt.getMonth() + 1 << 21 | dt.getDate() << 16 | dt.getHours() << 11 | dt.getMinutes() << 5 | dt.getSeconds() >>> 1), b += 4;
  if (c != -1) {
    wbytes(d, b, f.crc);
    wbytes(d, b + 4, c < 0 ? -c - 2 : c);
    wbytes(d, b + 8, f.size);
  }
  wbytes(d, b + 12, fl2);
  wbytes(d, b + 14, exl), b += 16;
  if (ce != null) {
    wbytes(d, b, col);
    wbytes(d, b + 6, f.attrs);
    wbytes(d, b + 10, ce), b += 14;
  }
  d.set(fn, b);
  b += fl2;
  if (exl) {
    for (var k in ex) {
      var exf = ex[k], l = exf.length;
      wbytes(d, b, +k);
      wbytes(d, b + 2, l);
      d.set(exf, b + 4), b += 4 + l;
    }
  }
  if (col)
    d.set(co, b), b += col;
  return b;
};
var wzf = function(o, b, c, d, e) {
  wbytes(o, b, 101010256);
  wbytes(o, b + 8, c);
  wbytes(o, b + 10, c);
  wbytes(o, b + 12, d);
  wbytes(o, b + 16, e);
};
function zipSync(data, opts) {
  if (!opts)
    opts = {};
  var r = {};
  var files = [];
  fltn(data, "", r, opts);
  var o = 0;
  var tot = 0;
  for (var fn in r) {
    var _a2 = r[fn], file = _a2[0], p = _a2[1];
    var compression = p.level == 0 ? 0 : 8;
    var f = strToU8(fn), s = f.length;
    var com = p.comment, m = com && strToU8(com), ms = m && m.length;
    var exl = exfl(p.extra);
    if (s > 65535)
      err(11);
    var d = compression ? deflateSync(file, p) : file, l = d.length;
    var c = crc();
    c.p(file);
    files.push(mrg(p, {
      size: file.length,
      crc: c.d(),
      c: d,
      f,
      m,
      u: s != fn.length || m && com.length != ms,
      o,
      compression
    }));
    o += 30 + s + exl + l;
    tot += 76 + 2 * (s + exl) + (ms || 0) + l;
  }
  var out = new u8(tot + 22), oe = o, cdl = tot - o;
  for (var i2 = 0; i2 < files.length; ++i2) {
    var f = files[i2];
    wzh(out, f.o, f, f.f, f.u, f.c.length);
    var badd = 30 + f.f.length + exfl(f.extra);
    out.set(f.c, f.o + badd);
    wzh(out, o, f, f.f, f.u, f.c.length, f.o, f.m), o += 16 + badd + (f.m ? f.m.length : 0);
  }
  wzf(out, o, files.length, cdl, oe);
  return out;
}

// desktop/backup-zip.ts
import { inflateRawSync } from "node:zlib";

// lib/growth.ts
var MAX_STATE_BYTES = 5e6;
var MAX_REQUEST_BYTES = MAX_STATE_BYTES + 8e3;
function isDateString(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date2 = /* @__PURE__ */ new Date(`${value}T12:00:00Z`);
  return Number.isFinite(date2.getTime()) && date2.toISOString().slice(0, 10) === value;
}
function weekStart(date2) {
  if (!isDateString(date2)) throw new GrowthValidationError("\u65E5\u671F\u683C\u5F0F\u4E0D\u6B63\u786E\u3002");
  const day = /* @__PURE__ */ new Date(`${date2}T12:00:00Z`);
  day.setUTCDate(day.getUTCDate() - (day.getUTCDay() + 6) % 7);
  return day.toISOString().slice(0, 10);
}
var GrowthValidationError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "GrowthValidationError";
  }
};
function fail(message) {
  throw new GrowthValidationError(message);
}
function object(value, label) {
  if (!value || typeof value !== "object" || Array.isArray(value)) fail(`${label}\u683C\u5F0F\u4E0D\u6B63\u786E\u3002`);
  return value;
}
function string(value, label, max = 2e4, required = false) {
  if (typeof value !== "string" || value.length > max || required && !value.trim()) {
    fail(`${label}${required ? "\u4E0D\u80FD\u4E3A\u7A7A\uFF0C\u4E14" : ""}\u5FC5\u987B\u662F\u957F\u5EA6\u4E0D\u8D85\u8FC7 ${max} \u7684\u6587\u5B57\u3002`);
  }
  return value;
}
function id(value, label) {
  const result = string(value, label, 100, true);
  if (!/^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(result)) fail(`${label}\u683C\u5F0F\u4E0D\u6B63\u786E\u3002`);
  return result;
}
function array(value, label, max) {
  if (!Array.isArray(value) || value.length > max) fail(`${label}\u5FC5\u987B\u662F\u5217\u8868\uFF0C\u6700\u591A ${max} \u9879\u3002`);
  return value;
}
function date(value, label) {
  const result = string(value, label, 10, true);
  if (!isDateString(result)) fail(`${label}\u5FC5\u987B\u662F\u6709\u6548\u7684 YYYY-MM-DD \u65E5\u671F\u3002`);
  return result;
}
function timestamp(value, label) {
  const result = string(value, label, 40, true);
  const matched = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.(\d{1,3}))?Z$/.exec(result);
  if (!matched || !Number.isFinite(Date.parse(result))) {
    fail(`${label}\u5FC5\u987B\u662F\u6709\u6548\u7684 UTC \u65F6\u95F4\u3002`);
  }
  const canonical = `${result.slice(0, 19)}.${(matched[1] ?? "").padEnd(3, "0")}Z`;
  if (new Date(result).toISOString() !== canonical) fail(`${label}\u65E5\u671F\u6216\u65F6\u523B\u65E0\u6548\u3002`);
  return result;
}
function status(value) {
  if (value !== "draft" && value !== "verified" && value !== "outdated") fail("\u6280\u80FD\u72B6\u6001\u4E0D\u6B63\u786E\u3002");
  return value;
}
function integer(value, label, maximum) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 1 || value > maximum) fail(`${label}\u4E0D\u6B63\u786E\u3002`);
  return value;
}
function imageId(value) {
  if (typeof value !== "string" || !/^[a-f0-9]{64}$/.test(value)) fail("\u56FE\u7247\u7F16\u53F7\u4E0D\u6B63\u786E\u3002");
  return value;
}
function media(value) {
  const result = {};
  if (value.images !== void 0) {
    result.images = array(value.images, "\u7B14\u8BB0\u56FE\u7247", 20).map((item) => {
      const image = object(item, "\u7B14\u8BB0\u56FE\u7247");
      if (image.mime !== "image/png" && image.mime !== "image/jpeg") fail("\u56FE\u7247\u4EC5\u652F\u6301 PNG \u6216 JPEG \u683C\u5F0F\u3002");
      const width = integer(image.width, "\u56FE\u7247\u5BBD\u5EA6", 12e3), height = integer(image.height, "\u56FE\u7247\u9AD8\u5EA6", 12e3);
      if (width * height > 4e7) fail("\u56FE\u7247\u5C3A\u5BF8\u8FC7\u5927\uFF0C\u8BF7\u7F29\u5C0F\u540E\u518D\u63D2\u5165\u3002");
      return { id: imageId(image.id), name: string(image.name, "\u56FE\u7247\u540D\u79F0", 240, true), mime: image.mime, width, height, bytes: integer(image.bytes, "\u56FE\u7247\u5927\u5C0F", 1e7) };
    });
    unique(result.images.map((image) => image.id), "\u7B14\u8BB0\u56FE\u7247");
  }
  if (value.blocks !== void 0) {
    let textLength = 0;
    const available = new Set(result.images?.map((image) => image.id));
    result.blocks = array(value.blocks, "\u56FE\u6587\u6BB5\u843D", 200).map((item) => {
      const block = object(item, "\u56FE\u6587\u6BB5\u843D"), blockId = id(block.id, "\u6BB5\u843D\u7F16\u53F7");
      if (block.type === "text") {
        const text = string(block.text, "\u6BB5\u843D\u6587\u5B57");
        textLength += text.length;
        return { id: blockId, type: "text", text };
      }
      if (block.type !== "image") fail("\u56FE\u6587\u6BB5\u843D\u7C7B\u578B\u4E0D\u6B63\u786E\u3002");
      const image = imageId(block.imageId);
      if (!available.has(image)) fail("\u56FE\u6587\u6BB5\u843D\u5F15\u7528\u4E86\u4E0D\u5B58\u5728\u7684\u56FE\u7247\u3002");
      return { id: blockId, type: "image", imageId: image };
    });
    unique(result.blocks.map((block) => block.id), "\u56FE\u6587\u6BB5\u843D");
    if (textLength > 2e4) fail("\u6B63\u6587\u6587\u5B57\u4E0D\u80FD\u8D85\u8FC7 20000 \u4E2A\u5B57\u3002");
    const body = "done" in value ? value.done : value.steps;
    if (typeof body === "string" && body !== blocksText(result.blocks)) fail("\u6B63\u6587\u4E0E\u56FE\u6587\u6BB5\u843D\u6587\u5B57\u4E0D\u4E00\u81F4\uFF0C\u8BF7\u91CD\u65B0\u4FDD\u5B58\u3002");
  }
  return result;
}
function blocksText(blocks) {
  return blocks.filter((block) => block.type === "text").map((block) => block.text).join("");
}
function collectImages(state) {
  const result = /* @__PURE__ */ new Map();
  for (const source of [...state.records, ...state.skills, ...state.skills.flatMap((skill) => skill.versions)]) {
    for (const image of source.images ?? []) {
      const previous = result.get(image.id);
      if (previous && (previous.mime !== image.mime || previous.width !== image.width || previous.height !== image.height || previous.bytes !== image.bytes)) fail("\u540C\u4E00\u56FE\u7247\u7684\u8D44\u6599\u4E0D\u4E00\u81F4\u3002");
      if (!previous) result.set(image.id, image);
    }
  }
  return [...result.values()];
}
function links(value) {
  return array(value, "\u8D44\u6599\u94FE\u63A5", 20).map((item) => {
    const link = object(item, "\u8D44\u6599\u94FE\u63A5");
    const url = string(link.url, "\u8D44\u6599\u5730\u5740", 2048, true);
    try {
      const parsed = new URL(url);
      if (!["http:", "https:"].includes(parsed.protocol) || parsed.username || parsed.password) fail("\u8D44\u6599\u94FE\u63A5\u4EC5\u652F\u6301\u4E0D\u542B\u8D26\u53F7\u5BC6\u7801\u7684 HTTP \u6216 HTTPS \u5730\u5740\u3002");
    } catch (error) {
      if (error instanceof GrowthValidationError) throw error;
      fail("\u8D44\u6599\u94FE\u63A5\u5730\u5740\u4E0D\u6B63\u786E\uFF0C\u8BF7\u586B\u5199\u5B8C\u6574\u7684 HTTP \u6216 HTTPS \u5730\u5740\u3002");
    }
    return { label: string(link.label, "\u8D44\u6599\u540D\u79F0", 240), url };
  });
}
function skillFields(value) {
  return {
    ...media(value),
    title: string(value.title, "\u6280\u80FD\u6807\u9898", 240, true),
    scenario: string(value.scenario, "\u9002\u7528\u573A\u666F"),
    prerequisites: string(value.prerequisites, "\u51C6\u5907\u6761\u4EF6"),
    steps: string(value.steps, "\u64CD\u4F5C\u6B65\u9AA4"),
    parameters: string(value.parameters, "\u5173\u952E\u53C2\u6570"),
    pitfalls: string(value.pitfalls, "\u5E38\u89C1\u95EE\u9898"),
    status: status(value.status),
    links: links(value.links)
  };
}
function unique(values, label) {
  if (new Set(values).size !== values.length) fail(`${label}\u4E2D\u5B58\u5728\u91CD\u590D\u9879\u3002`);
}
function validateRevision(value) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0 || value >= Number.MAX_SAFE_INTEGER) fail("\u540C\u6B65\u7248\u672C\u4E0D\u6B63\u786E\uFF0C\u8BF7\u5237\u65B0\u540E\u91CD\u8BD5\u3002");
  return value;
}
function validateState(input) {
  const value = object(input, "\u6210\u957F\u6570\u636E");
  if (value.schemaVersion !== 1 && value.schemaVersion !== 2 && value.schemaVersion !== 3) fail("\u5907\u4EFD\u7248\u672C\u4E0D\u53D7\u652F\u6301\uFF0C\u8BF7\u4F7F\u7528\u5F53\u524D\u7248\u672C\u5BFC\u51FA\u7684\u5907\u4EFD\u3002");
  const revision = validateRevision(value.revision);
  const categories = array(value.categories, "\u5206\u7C7B", 100).map((item) => {
    const category = object(item, "\u5206\u7C7B");
    return { id: id(category.id, "\u5206\u7C7B\u7F16\u53F7"), name: string(category.name, "\u5206\u7C7B\u540D\u79F0", 100, true), parentId: category.parentId === null ? null : id(category.parentId, "\u4E0A\u7EA7\u5206\u7C7B\u7F16\u53F7") };
  });
  if (!categories.length) fail("\u8BF7\u81F3\u5C11\u4FDD\u7559\u4E00\u4E2A\u5206\u7C7B\u3002");
  const records = array(value.records, "\u6BCF\u65E5\u8BB0\u5F55", 5e3).map((item) => {
    const record = object(item, "\u6BCF\u65E5\u8BB0\u5F55");
    if (record.kind !== void 0 && record.kind !== "idea" && record.kind !== "progress") fail("\u7B14\u8BB0\u7C7B\u578B\u4E0D\u6B63\u786E\u3002");
    const tags = array(record.tags, "\u6807\u7B7E", 20).map((tag) => string(tag, "\u6807\u7B7E", 64, true));
    unique(tags, "\u6807\u7B7E");
    return {
      ...media(record),
      ...record.kind === void 0 ? {} : { kind: record.kind },
      id: id(record.id, "\u8BB0\u5F55\u7F16\u53F7"),
      date: date(record.date, "\u8BB0\u5F55\u65E5\u671F"),
      categoryId: id(record.categoryId, "\u8BB0\u5F55\u5206\u7C7B"),
      title: string(record.title, "\u8BB0\u5F55\u6807\u9898", 240, true),
      done: string(record.done, "\u505A\u4E86\u4EC0\u4E48"),
      learned: string(record.learned, "\u5B66\u5230\u4EC0\u4E48"),
      next: string(record.next, "\u4E0B\u4E00\u6B65"),
      tags,
      links: links(record.links),
      createdAt: timestamp(record.createdAt, "\u521B\u5EFA\u65F6\u95F4"),
      updatedAt: timestamp(record.updatedAt, "\u66F4\u65B0\u65F6\u95F4")
    };
  });
  const skills = array(value.skills, "\u6280\u80FD\u5361", 2e3).map((item) => {
    const skill = object(item, "\u6280\u80FD\u5361");
    const sourceRecordIds = array(skill.sourceRecordIds, "\u6765\u6E90\u8BB0\u5F55", 100).map((source) => id(source, "\u6765\u6E90\u8BB0\u5F55\u7F16\u53F7"));
    unique(sourceRecordIds, "\u6765\u6E90\u8BB0\u5F55");
    return {
      ...skillFields(skill),
      id: id(skill.id, "\u6280\u80FD\u7F16\u53F7"),
      categoryId: id(skill.categoryId, "\u6280\u80FD\u5206\u7C7B"),
      sourceRecordIds,
      versions: array(skill.versions, "\u6280\u80FD\u5386\u53F2\u7248\u672C", 40).map((item2) => {
        const version = object(item2, "\u6280\u80FD\u5386\u53F2\u7248\u672C");
        return { ...skillFields(version), savedAt: timestamp(version.savedAt, "\u7248\u672C\u65F6\u95F4") };
      }),
      createdAt: timestamp(skill.createdAt, "\u521B\u5EFA\u65F6\u95F4"),
      updatedAt: timestamp(skill.updatedAt, "\u66F4\u65B0\u65F6\u95F4")
    };
  });
  const weeklyReviews = array(value.weeklyReviews, "\u6BCF\u5468\u56DE\u987E", 1e3).map((item) => {
    const review = object(item, "\u6BCF\u5468\u56DE\u987E");
    const start = date(review.weekStart, "\u56DE\u987E\u5468\u8D77\u59CB\u65E5\u671F");
    if (weekStart(start) !== start) fail("\u6BCF\u5468\u56DE\u987E\u7684\u8D77\u59CB\u65E5\u671F\u5FC5\u987B\u662F\u5468\u4E00\u3002");
    return {
      id: id(review.id, "\u56DE\u987E\u7F16\u53F7"),
      weekStart: start,
      progress: string(review.progress, "\u672C\u5468\u8FDB\u6B65"),
      obstacles: string(review.obstacles, "\u53CD\u590D\u95EE\u9898"),
      focus: string(review.focus, "\u4E0B\u5468\u91CD\u70B9"),
      createdAt: timestamp(review.createdAt, "\u521B\u5EFA\u65F6\u95F4"),
      updatedAt: timestamp(review.updatedAt, "\u66F4\u65B0\u65F6\u95F4")
    };
  });
  unique([...categories, ...records, ...skills, ...weeklyReviews].map((item) => item.id), "\u6570\u636E\u7F16\u53F7");
  unique(weeklyReviews.map((item) => item.weekStart), "\u6BCF\u5468\u56DE\u987E\u65E5\u671F");
  const categoryById = new Map(categories.map((item) => [item.id, item]));
  for (const category of categories) {
    let current = category;
    const visited = /* @__PURE__ */ new Set();
    while (current) {
      if (visited.has(current.id)) fail("\u5206\u7C7B\u4E0D\u80FD\u628A\u81EA\u8EAB\u6216\u4E0B\u7EA7\u5206\u7C7B\u8BBE\u4E3A\u4E0A\u7EA7\u3002");
      visited.add(current.id);
      if (current.parentId === null) break;
      current = categoryById.get(current.parentId);
      if (!current) fail("\u4E0A\u7EA7\u5206\u7C7B\u4E0D\u5B58\u5728\u3002");
    }
  }
  for (const item of [...records, ...skills]) if (!categoryById.has(item.categoryId)) fail("\u8BB0\u5F55\u6216\u6280\u80FD\u5F15\u7528\u4E86\u4E0D\u5B58\u5728\u7684\u5206\u7C7B\u3002");
  const result = { schemaVersion: value.schemaVersion, revision, categories, records, skills, weeklyReviews };
  const images = collectImages(result);
  const mediaPresent = [...records, ...skills, ...skills.flatMap((skill) => skill.versions)].some((source) => source.images !== void 0 || source.blocks !== void 0);
  if (images.length || mediaPresent || result.schemaVersion === 3) result.schemaVersion = 3;
  else if (result.schemaVersion === 2 || records.some((record) => record.kind === "progress")) result.schemaVersion = 2;
  if (new TextEncoder().encode(JSON.stringify(result)).byteLength > MAX_STATE_BYTES) fail("\u6570\u636E\u8D85\u8FC7 5 MB\uFF0C\u8BF7\u5148\u5BFC\u51FA\u5907\u4EFD\uFF0C\u518D\u7CBE\u7B80\u8FC7\u957F\u5185\u5BB9\u6216\u6280\u80FD\u5386\u53F2\u7248\u672C\u3002");
  return result;
}

// desktop/backup-zip.ts
var MAX_BACKUP_BYTES = 21e7;
var MAX_BACKUP_CONTENT_BYTES = 2e8;
var MANIFEST = "growth-state.json";
var allowedName = (name) => name === MANIFEST || /^assets\/[a-f0-9]{64}$/.test(name);
function invalid(message = "\u56FE\u7247\u5907\u4EFD\u683C\u5F0F\u4E0D\u6B63\u786E\u3002") {
  throw new Error(message);
}
var crcTable = Array.from({ length: 256 }, (_, value) => {
  let crc2 = value;
  for (let bit = 0; bit < 8; bit++) crc2 = crc2 >>> 1 ^ (crc2 & 1 ? 3988292384 : 0);
  return crc2 >>> 0;
});
function crc32(bytes) {
  let crc2 = 4294967295;
  for (const byte of bytes) crc2 = crcTable[(crc2 ^ byte) & 255] ^ crc2 >>> 8;
  return (crc2 ^ 4294967295) >>> 0;
}
function entries(bytes) {
  if (bytes.length > MAX_BACKUP_BYTES || bytes.length < 22) invalid("\u5907\u4EFD\u6587\u4EF6\u8FC7\u5927\u6216\u4E0D\u5B8C\u6574\u3002");
  let end = -1;
  for (let offset2 = bytes.length - 22; offset2 >= Math.max(0, bytes.length - 65557); offset2--) {
    if (bytes.readUInt32LE(offset2) === 101010256 && offset2 + 22 + bytes.readUInt16LE(offset2 + 20) === bytes.length) {
      end = offset2;
      break;
    }
  }
  if (end < 0 || bytes.readUInt16LE(end + 4) || bytes.readUInt16LE(end + 6)) invalid();
  const count = bytes.readUInt16LE(end + 10), directorySize = bytes.readUInt32LE(end + 12), directoryOffset = bytes.readUInt32LE(end + 16);
  if (count !== bytes.readUInt16LE(end + 8) || count < 1 || count > 1e4 || directoryOffset + directorySize !== end) invalid();
  const result = /* @__PURE__ */ new Map();
  let offset = directoryOffset, total = 0;
  for (let index = 0; index < count; index++) {
    if (offset + 46 > end || bytes.readUInt32LE(offset) !== 33639248) invalid();
    const flags = bytes.readUInt16LE(offset + 8), method = bytes.readUInt16LE(offset + 10), crc2 = bytes.readUInt32LE(offset + 16);
    const packedSize = bytes.readUInt32LE(offset + 20), size = bytes.readUInt32LE(offset + 24);
    const nameSize = bytes.readUInt16LE(offset + 28), extraSize = bytes.readUInt16LE(offset + 30), commentSize = bytes.readUInt16LE(offset + 32), localOffset = bytes.readUInt32LE(offset + 42);
    if (flags & 1 || ![0, 8].includes(method) || offset + 46 + nameSize + extraSize + commentSize > end || nameSize > 100 || bytes.readUInt16LE(offset + 34)) invalid();
    const nameBytes = bytes.subarray(offset + 46, offset + 46 + nameSize), name = nameBytes.toString("ascii");
    if ([...nameBytes].some((byte) => byte > 127) || !allowedName(name) || result.has(name)) invalid("\u5907\u4EFD\u542B\u6709\u65E0\u6548\u8DEF\u5F84\u6216\u91CD\u590D\u6587\u4EF6\u3002");
    if (size > (name === MANIFEST ? 15e6 : 1e7)) invalid("\u5907\u4EFD\u4E2D\u7684\u6587\u4EF6\u8FC7\u5927\u3002");
    total += size;
    if (total > MAX_BACKUP_CONTENT_BYTES) invalid("\u5907\u4EFD\u89E3\u538B\u540E\u7684\u5185\u5BB9\u8FC7\u5927\u3002");
    if (localOffset + 30 > directoryOffset || bytes.readUInt32LE(localOffset) !== 67324752) invalid();
    const localNameSize = bytes.readUInt16LE(localOffset + 26), localExtraSize = bytes.readUInt16LE(localOffset + 28);
    const dataOffset = localOffset + 30 + localNameSize + localExtraSize;
    if (dataOffset + packedSize > directoryOffset || bytes.readUInt16LE(localOffset + 6) !== flags || bytes.readUInt16LE(localOffset + 8) !== method || !bytes.subarray(localOffset + 30, localOffset + 30 + localNameSize).equals(nameBytes)) invalid();
    if (!(flags & 8) && (bytes.readUInt32LE(localOffset + 14) !== crc2 || bytes.readUInt32LE(localOffset + 18) !== packedSize || bytes.readUInt32LE(localOffset + 22) !== size)) invalid();
    result.set(name, { size, crc: crc2, dataOffset, packedSize, method });
    offset += 46 + nameSize + extraSize + commentSize;
  }
  if (offset !== end || !result.has(MANIFEST)) invalid("\u5907\u4EFD\u7F3A\u5C11\u5DE5\u4F5C\u624B\u8BB0\u6570\u636E\u6587\u4EF6\u3002");
  return result;
}
function decodeImageBackup(bytes) {
  const directory = entries(bytes);
  const files = {};
  for (const [name, info] of directory) {
    const packed = bytes.subarray(info.dataOffset, info.dataOffset + info.packedSize);
    try {
      files[name] = info.method === 0 ? Buffer.from(packed) : inflateRawSync(packed, { maxOutputLength: Math.max(1, info.size) });
    } catch {
      invalid("\u56FE\u7247\u5907\u4EFD\u65E0\u6CD5\u89E3\u538B\uFF0C\u6587\u4EF6\u53EF\u80FD\u5DF2\u635F\u574F\u6216\u5185\u5BB9\u8D85\u9650\u3002");
    }
    if (files[name].length !== info.size || crc32(files[name]) !== info.crc) invalid("\u5907\u4EFD\u4E2D\u7684\u6587\u4EF6\u6821\u9A8C\u5931\u8D25\u3002");
  }
  const state = validateState(JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(files[MANIFEST])));
  const images = collectImages(state), assets = /* @__PURE__ */ new Map();
  if (directory.size !== images.length + 1) invalid("\u5907\u4EFD\u5305\u542B\u672A\u767B\u8BB0\u7684\u56FE\u7247\u6587\u4EF6\u3002");
  for (const image of images) {
    const bytes2 = files[`assets/${image.id}`];
    if (!bytes2 || bytes2.length !== image.bytes || createHash("sha256").update(bytes2).digest("hex") !== image.id) invalid("\u5907\u4EFD\u56FE\u7247\u7F3A\u5931\u6216\u6821\u9A8C\u5931\u8D25\u3002");
    assets.set(image.id, Buffer.from(bytes2));
  }
  return { state, assets };
}
function encodeImageBackup(state, assets) {
  const checked = validateState(state), images = collectImages(checked);
  const manifest = Buffer.from(JSON.stringify(checked, null, 2));
  const files = { [MANIFEST]: manifest };
  let size = manifest.length;
  for (const image of images) {
    const bytes = assets.get(image.id);
    if (!bytes || bytes.length !== image.bytes || createHash("sha256").update(bytes).digest("hex") !== image.id) invalid("\u56FE\u7247\u7F3A\u5931\u6216\u635F\u574F\uFF0C\u65E0\u6CD5\u5BFC\u51FA\u5B8C\u6574\u5907\u4EFD\u3002");
    size += bytes.length;
    if (size > MAX_BACKUP_CONTENT_BYTES) invalid("\u56FE\u7247\u5907\u4EFD\u8D85\u8FC7 200 MB\uFF0C\u8BF7\u51CF\u5C11\u8FC7\u5927\u7684\u56FE\u7247\u540E\u518D\u5BFC\u51FA\u3002");
    files[`assets/${image.id}`] = bytes;
  }
  if (images.length + 1 > 1e4) invalid("\u56FE\u7247\u6570\u91CF\u8FC7\u591A\uFF0C\u65E0\u6CD5\u5BFC\u51FA\u5907\u4EFD\u3002");
  const result = Buffer.from(zipSync(files, { level: 0 }));
  if (result.length > MAX_BACKUP_BYTES) invalid("\u56FE\u7247\u5907\u4EFD\u8FC7\u5927\u3002");
  return result;
}
export {
  MAX_BACKUP_BYTES,
  MAX_BACKUP_CONTENT_BYTES,
  decodeImageBackup,
  encodeImageBackup
};
/*! fflate
MIT License

Copyright (c) 2020 Arjun Barrett

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
